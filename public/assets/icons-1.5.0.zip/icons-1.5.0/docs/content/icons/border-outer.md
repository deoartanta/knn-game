---
title: Border outer
categories:
  - UI and keyboard
tags:
  - borders
---
